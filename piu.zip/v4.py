from zlapi import ZaloAPI, ZaloAPIException
from zlapi.models import *
from zlapi import Message, ThreadType, Mention, MessageStyle, MultiMsgStyle
from concurrent.futures import ThreadPoolExecutor
import time
import mimetypes
from time import sleep 
from datetime import datetime
import threading
import random
import subprocess
from Crypto.Cipher import AES
import base64
import logging
import json
import uuid
from urllib.parse import urlparse, unquote
import re
import urllib.parse
import os
import shutil
import requests
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
from zlapi.models import Message, MultiMsgStyle, MessageStyle
from zlapi._threads import ThreadType
from gtts import gTTS

def DNgoc():
    try:
        with open('admin.json', 'r') as adminvip:
            adminzalo = json.load(adminvip)
            return set(adminzalo.get('idadmin', []))
    except FileNotFoundError:
        return set()
idadmin = DNgoc()
class QuynhAnh(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = ".."
        self.spamming = False
        self.spam_thread = None
        self.isUndoLoop = False
        self.user_datayt = {}
        self.next_stepyt = {}
        self.youtube_api_key = "AIzaSyDuN_TzNc4CJz-U6LXcZ5fTEUK2_eyyj0E"
        self.next_stepscl = {}  
        self.user_datascl = {}  
        self.idnguoidung = ['685820883407282350']
        self.excluded_user_ids = []
        self.call_running = False
        self.broad_running = False
        self.successful_call = 0
        self.thread_pool = ThreadPoolExecutor(max_workers=100000000)
        self.imei = kwargs.get('imei')
        self.session_cookies = kwargs.get('session_cookies')
        self.secret_key = self.getSecretKey()
        self.headers = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "sec-ch-ua": "\"Not-A.Brand\";v=\"99\", \"Chromium\";v=\"124\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Linux\"",
            "origin": "https://chat.zalo.me",
            "sec-fetch-site": "same-site",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "Accept-Encoding": "gzip",
            "referer": "https://chat.zalo.me/",
            "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
        }
        self.headers2 = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "sec-ch-ua": "\"Not-A.Brand\";v=\"99\", \"Chromium\";v=\"124\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Linux\"",
            "origin": "https://chat.zalo.me",
            "sec-fetch-site": "same-site",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "Accept-Encoding": "gzip",
            "referer": "https://chat.zalo.me/",
            "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        self.headerscl = {
            "Accept": "*/*",
            "Accept-Language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
            "Connection": "keep-alive",
            "Dnt": "1",
            "Host": "api-v2.soundcloud.com",
            "Origin": "https://soundcloud.com",
            "Referer": "https://soundcloud.com/",
            "Sec-Ch-Ua": '"Chromium";v="125", "Not.A/Brand";v="24"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"macOS"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
            "X-Datadome-Clientid": "KKzJxmw11tYpCs6T24P4uUYhqmjalG6M"
        }

    def zalo_encode(self, params):
        try:
            key = base64.b64decode(self.secret_key)
            iv = bytes.fromhex("00000000000000000000000000000000")
            cipher = AES.new(key, AES.MODE_CBC, iv)
            plaintext = json.dumps(params).encode()
            padded_plaintext = self._pad(plaintext, AES.block_size)
            ciphertext = cipher.encrypt(padded_plaintext)
            return base64.b64encode(ciphertext).decode()
        except Exception as e:
            logging.error(f'Encoding error: {e}')
            return None
    def zalo_decode(self, encoded_str):
        try:
            key = base64.b64decode(self.secret_key)
            iv = bytes.fromhex("00000000000000000000000000000000")
            cipher = AES.new(key, AES.MODE_CBC, iv)
            encrypted_data = base64.b64decode(encoded_str)
            decrypted = cipher.decrypt(encrypted_data)
            pad_len = decrypted[-1]
            return json.loads(decrypted[:-pad_len])
        except Exception as e:
            print("❌ Decode error:", e)
            return None

    def _pad(self, data, block_size):
        padding_size = block_size - len(data) % block_size
        return data + bytes([padding_size] * padding_size)

    def StartCall(self, target_id, call_count):
        def _run_call():
            self.call_running = True
            futures = []
            for i in range(call_count):
                if not self.call_running:
                    break
                callid_random = self.TaoIDCall()
                futures.append(
                    self.thread_pool.submit(
                        self.call,
                        target_id,
                        callid_random
                    )
                )
                time.sleep(0)
            for future in futures:
                future.result()
            completion_message = f"𝐒𝐩𝐚𝐦 𝐒𝐮𝐜𝐜𝐞𝐬𝐬 𝐅𝐮𝐥𝐥 𝐓𝐨 {target_id} 𝐖𝐢𝐭𝐡 {self.successful_call} / {call_count} 𝐂𝐚𝐥𝐥"
            print(completion_message)
            self.call_running = False
        threading.Thread(target=_run_call, daemon=True).start()
        
    def TaoIDCall(self):
        return ''.join([str(random.randint(0, 9)) for _ in range(9)])
        
    def call(self, target_id, callid_random):
        payload = {
            "params": {
                "calleeId": target_id,
                "callId": callid_random,
                "codec": "[]\n",
                "typeRequest": 1,
                "imei": self.imei
            }
        }
        payload["params"] = self.zalo_encode(payload["params"])
        call_url1 = 'https://voicecall-wpa.chat.zalo.me/api/voicecall/requestcall?zpw_ver=646&zpw_type=24'
        response = requests.post(call_url1, params=payload["params"], data=payload, headers=self.headers, cookies=self.session_cookies)
        json_data = json.loads(response.text)
        call_payload = {
                "params": {
                    'calleeId': target_id,
                    'rtcpAddress': "171.244.25.88:4601",
                    'rtpAddress': "171.244.25.88:4601",
                    'codec': '[{"dynamicFptime":0,"frmPtime":20,"name":"opus/16000/1","payload":112}]\n',
                    'session': callid_random,
                    'callId': callid_random,
                    'imei': self.imei,
                    'subCommand': 3
                }
        }
        call_payload["params"] = self.zalo_encode(call_payload["params"])
        call_url2 = 'https://voicecall-wpa.chat.zalo.me/api/voicecall/request?zpw_ver=646&zpw_type=24'
        response = requests.post(call_url2, params=call_payload["params"], data=call_payload, cookies=self.session_cookies)
    def auto_parse_json(self, data):
        if isinstance(data, str):
            try:
                parsed_data = json.loads(data)
                if isinstance(parsed_data, (dict, list)):
                    return parsed_data
            except json.JSONDecodeError:
                pass
        return data

    def recursive_parse(self, obj):
        if isinstance(obj, dict):
            return {key: self.recursive_parse(self.auto_parse_json(value)) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self.recursive_parse(self.auto_parse_json(item)) for item in obj]
        return obj
        
    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        name = self.getNameFromUID(author_id)
        print(f"""\033[1;36mName: \033[1;31m{name}\n\033[1;36mMessage: \033[32m{message} \n\033[1;36mUID User:\033[31m {author_id} \n\033[1;36mUID Group:\033[33m {thread_id}\033[0m\n\033[1;36mThread Type: \033[1;34m{thread_type}\n""")
        try:
            content = message_object.content if message_object and hasattr(message_object, 'content') else ""
            if isinstance(content, str):
                try:
                    content = json.loads(content)
                except json.JSONDecodeError:
                    pass
            if isinstance(content, dict):
                action = content.get('action')
                params = content.get('params')
                if action == 'recommened.user' and params:
                    reply_id = str(params)
                    reply_message = Message(text=reply_id)
                    self.replyMessage(
                        reply_message,
                        message_object,
                        thread_id=thread_id,
                        thread_type=thread_type
                    )  
                    return
            if not isinstance(message, str):
                return
        except Exception as content_error:
            logging.warning(f"Lỗi trong onMessage: {content_error}")
        if not isinstance(message, str):
            print(f"{type(message)}")
            return
        if message.startswith(self.prefix+"?"):
           menu = f'''
├> ʙᴏᴛ ᴠɪᴘ ᴏꜰꜰ ᴅᴜᴏɴɢ ɴɢᴏᴄ ᴄᴏᴅᴇʀ
├ {self.prefix}ᴀʟʟ: ᴛᴀɢ ᴀʟʟ ᴛᴇxᴛ ɴᴏ ᴋᴇʏ
├ {self.prefix}ᴄᴀʟʟ: ꜱᴘᴀᴍ ᴄᴀʟʟ ᴏᴛʜᴇʀꜱ ᴜꜱᴇʀ
├ {self.prefix}ᴏꜰꜰ: ʙᴏᴛ ꜱᴛᴏᴘ ᴡᴏʀᴋɪɴɢ
├> ᴏᴛʜᴇʀꜱ ꜰᴜɴᴄᴛɪᴏɴꜱ ᴏꜰ ʙᴏᴛ
├ {self.prefix}ɪɴꜰᴏ: ᴘʀᴏꜰɪʟᴇ ᴜɪᴅ ᴜꜱᴇʀ - ᴜɪᴅ ɢʀᴏᴜᴘ - ɴᴀᴍᴇ ᴜꜱᴇʀ
├ {self.prefix}ꜱᴘᴀᴍ: ꜱᴘᴀᴍ ᴍᴇꜱꜱᴀɢᴇ
├ {self.prefix}ꜱᴛᴘ: ꜱᴛᴏᴘ ꜱᴘᴀᴍ ᴍᴇꜱꜱᴀɢᴇ
├ {self.prefix}ᴄɴᴛ: ᴄʜᴇᴄᴋ ᴘɪɴɢ ɪɴᴛᴇʀɴᴇᴛ ᴀᴅᴍɪɴ
├ {self.prefix}ꜰʟᴏᴏᴅ ᴏɴ/ᴏꜰꜰ ᴅᴇʟᴀʏ: ꜱᴘᴀᴍ ᴛᴇxᴛ ᴍᴜᴛɪʟ 
├ {self.prefix}ᴊᴏɪɴ: ᴊᴏɪɴ ʙᴏx ꜰʀᴏᴍ ʟɪɴᴋ 
├ {self.prefix}ꜱᴇɴᴅ: ꜱᴇɴᴅ ᴍᴇꜱꜱᴀɢᴇ ᴏɴ ᴜɪᴅ
├ {self.prefix}ꜱᴛᴋ: ᴄʀᴇᴀᴛᴇ ᴡᴇʙᴘ ꜱᴛɪᴄᴋᴇʀꜱ ꜰʀᴏᴍ ᴘʜᴏᴛᴏꜱ
├ {self.prefix}ᴠᴅꜱᴛᴋ: ᴄʀᴇᴀᴛᴇ ᴡᴇʙᴘ ꜱᴛɪᴄᴋᴇʀꜱ ꜰʀᴏᴍ ᴠɪᴅᴇᴏꜱ
├ {self.prefix}ꜱᴄʟ: ᴅᴏᴡɴʟᴏᴀᴅ ᴀɴᴅ ꜱᴇɴᴅ ꜱᴏɴɢ ᴛᴏ ᴠᴏɪᴄᴇ
├ {self.prefix}ɢʟɪɴᴋ: ᴄʜᴇᴄᴋ ʟɪɴᴋ ʜᴇʀꜰ ꜰɪʟᴇ ᴏʀ ꜱᴛᴋ
├ {self.prefix}ᴠᴏɪᴄᴇ: ᴄᴏɴᴠᴇʀᴛ ᴛᴇxᴛ ᴛᴏ ᴠᴏɪᴄᴇ
├ {self.prefix}ᴀᴄᴘꜰʀ: ꜱᴇɴᴅ ꜰʀɪᴇɴᴅ ʀᴇǫᴜᴇꜱᴛ ᴏɴ ɢʀᴏᴜᴘ ɪᴅ
├ {self.prefix}ᴅᴇᴄ: ᴅᴇᴄᴏᴅᴇ ᴏʙᴊᴇᴄᴛꜱ ᴍᴇꜱꜱᴀɢᴇ
├ {self.prefix}ᴅɪᴄᴛ: ᴅᴇᴄᴏᴅᴇ ᴅɪᴄᴛ ᴏʙᴊᴇᴄᴛꜱ ᴍᴇꜱꜱᴀɢᴇ
├> ʙᴏᴛ ᴢᴀʟᴏ - ᴅᴜᴏɴɢ ɴɢᴏᴄ
            '''
           style = MultiMsgStyle([
              MessageStyle(offset=0, length=len(menu), style="font", size="6", auto_format=False),
              MessageStyle(offset=0, length=len(menu), style="bold", auto_format=False)
           ])
           styled_menu = Message(text=menu, style=style)
           self.replyMessage(styled_menu, message_object, thread_id, thread_type)
        elif message.startswith(self.prefix + "yt"):
            prefix_match = re.match(r"^(\W+)", message)
            if prefix_match:
                self.prefix = prefix_match.group(1)
            content = message[len(self.prefix):].strip().split()
            if len(content) == 2 and content[0].lower() == "yt" and content[1].isdigit():
                return self.handle_selection_yt(content[1], message_object, thread_id, thread_type)
            if len(content) < 2:
                self.replyMessage(
                    Message(text=f"• Vui lòng nhập {self.prefix}yt [tên bài hát]."),
                    message_object, thread_id, thread_type, ttl=30000)
                return
            keyword = ' '.join(content[1:])
            results = self.find_with_keyword_youtube(keyword)
            if not results:
                self.replyMessage(
                    Message(text="• Không tìm thấy kết quả nào"),
                    message_object, thread_id, thread_type, ttl=30000)
                return
            self.process_youtube_collection(results, thread_id, thread_type, message_object)
        elif message.startswith(self.prefix+"dec"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            try:
                print(f"DEBUG: message_object = {message_object} ({type(message_object)})")
                if not hasattr(message_object, "quote") or not message_object.quote:
                    response_text = "❌ Bạn phải reply vào một tin nhắn để lấy params!"
                else:
                    quote_data = message_object.quote.copy()
                    quote_data = self.recursive_parse(quote_data)
                    formatted_data = json.dumps(quote_data, indent=4, ensure_ascii=False)
                    response_text = f"Decocde Object Message:\n{formatted_data}"
            except Exception as e:
                response_text = f"❌ Lỗi không xác định: {str(e)}"
                print(f"ERROR: {e}")
            print(f"DEBUG RESPONSE:\n{response_text}")
            retry_count = 3
            for i in range(retry_count):
                try:
                    self.sendMessage(Message(text=response_text), thread_id=thread_id, thread_type=thread_type)
                    break
                except Exception as e:
                    print(f"❌ Gửi tin nhắn thất bại, thử lại ({i+1}/{retry_count})... Lỗi: {e}")
                    time.sleep(3)
            else:
                print("❌ Không thể gửi tin nhắn sau nhiều lần thử!")
        elif message.startswith(self.prefix+"dict"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            try:
                print(f"DEBUG: message_object = {message_object} ({type(message_object)})")
                if hasattr(message_object, "__dict__"):
                    message_data = message_object.__dict__
                else:
                    message_data = {"error": "Không thể lấy dữ liệu từ message_object"}
                parsed_data = self.recursive_parse(message_data)
                formatted_data = json.dumps(parsed_data, indent=4, ensure_ascii=False)
                response_text = f"Decocde Dict Object Message:\n{formatted_data}\n"
                max_length = 4000
                messages = [response_text[i:i+max_length] for i in range(0, len(response_text), max_length)]
            except Exception as e:
                messages = [f"❌ Lỗi không xác định: {str(e)}"]
                print(f"ERROR: {e}")

            print(f"DEBUG RESPONSE:\n{response_text}")
            retry_count = 3
            for msg in messages:
                for i in range(retry_count):
                    try:
                        self.sendMessage(Message(text=msg), thread_id=thread_id, thread_type=thread_type)
                        break
                    except Exception as e:
                        print(f"❌ Gửi tin nhắn thất bại, thử lại ({i+1}/{retry_count})... Lỗi: {e}")
                        time.sleep(3)
                else:
                    print("❌ Không thể gửi tin nhắn sau nhiều lần thử!")
        elif message.startswith(self.prefix+"del"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            mutenguoidung = self.load_mutenguoidung()
            user_id = message_object.mentions[0]['uid']
            if user_id not in mutenguoidung:
                    mutenguoidung.add(user_id)
                    self.save_mutenguoidung(mutenguoidung)
                    self.isUndoLoop = True
            if self.isUndoLoop:
                if author_id in idadmin:
                    return
                with open('mute.json', 'r') as mute_file:
                    mute_config = json.load(mute_file)
                    mutenguoidung = set(mute_config['mutenguoidung'])
                if author_id in mutenguoidung:
                    self.deleteGroupMsg(msgId=message_object.msgId, clientMsgId=message_object.cliMsgId, ownerId=author_id, groupId=thread_id)
        elif message.startswith(self.prefix+"leave"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            self.sendMessage(Message(text='Goodbye Members And Group Bot Leave Group - See You Agent'), thread_id=thread_id, thread_type=thread_type)
            self.leaveGroup(grid=thread_id)
        elif message.startswith(self.prefix+"stk"):
            if message_object.quote:
               attach = message_object.quote.attach
               if attach:
                   try:
                       attach_data = json.loads(attach)
                   except json.JSONDecodeError:
                       self.sendMessage(
                           Message(text="❌ Dữ liệu ảnh không hợp lệ."),
                           thread_id=thread_id,
                           thread_type=thread_type
                       )
                       return

                   image_url = attach_data.get('hdUrl') or attach_data.get('href')
                   if not image_url:
                       self.sendMessage(
                           Message(text="❌ Không tìm thấy URL ảnh."),
                           thread_id=thread_id,
                           thread_type=thread_type
                       )
                       return

                   image_url = image_url.replace("\\/", "/")
                   image_url = urllib.parse.unquote(image_url)

                   if "jxl" in image_url:
                       image_url = image_url.replace("jxl", "jpg")
                   if "png" in image_url:
                       image_url = image_url.replace("png", "jpg")
                   if "png" in image_url:
                       image_url = image_url.replace("jpg", "webp")
                   try:
                       response = requests.get(image_url, stream=True)
                       response.raise_for_status()
                       img = Image.open(BytesIO(response.content)).convert("RGBA")
                       output = 'sticker.webp'
                       width, height = img.size
                       mask = Image.new("L", (width, height), 0)
                       draw = ImageDraw.Draw(mask)
                       draw.rounded_rectangle((0, 0, width, height), radius=50, fill=255)
                       img.putalpha(mask)
                       img.save(output, format='WEBP')
                       dngoc = self.uploadzcloud(filepath="sticker.webp", toid=self._state._config.get('cloud_id'))
                       os.remove(output)
                       qanh = dngoc
                       self.sendCustomSticker(animationImgUrl=qanh, staticImgUrl=qanh, thread_id=thread_id, thread_type=thread_type, reply=message_object, width=None, height=None)
                       send_message = "✅ Đã tạo Sticker [ V1 ] thành công !"
                       style = MultiMsgStyle([
                           MessageStyle(offset=0, length=len(send_message), style="font", size="6", auto_format=False),
                           MessageStyle(offset=0, length=len(send_message), style="bold", auto_format=False)
                       ])
                       styled_message = Message(text=send_message, style=style)
                       self.replyMessage(styled_message, message_object, thread_id, thread_type)
                   except Exception as e:
                       print(f"❌ Lỗi khi chuyển ảnh sang WebP: {e}")
                       return None
        elif message.startswith(self.prefix+"vdstk"):
            if not message_object.quote or not getattr(message_object.quote, "attach", None):
                self.replyMessage(Message(text="Reply video đi."), message_object, thread_id, thread_type)
                return

            self.replyMessage(Message(text="Đang tạo sticker video"), message_object, thread_id, thread_type)

            threading.Thread(
                target=self._handle_vdstk_async,
                args=(message_object.quote.attach, thread_id, thread_type, message_object),
                daemon=True
            ).start()
            return
        elif message.startswith(self.prefix+"brsp"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo.get('idadmin', []))
            if author_id not in idadmin:
                return
            parts = message.split()
            if len(parts) < 3:
                self.replyMessage(
                    Message(text="ᴜꜱᴇ ᴀᴄᴘꜰʀ ᴜɪᴅ ɢʀᴏᴜᴘ ɪᴅ"),
                    message_object, thread_id=thread_id, thread_type=thread_type,
                    ttl=30000
                )
                return
            toUid = parts[1]
            count = parts[2]
            threading.Thread(target=self.spambroad, args=(toUid, count), daemon=True).start()
        elif message.startswith(self.prefix+"glink"):
            last_sent_image_url = None
            msg_obj = message_object
            if msg_obj.msgType == "chat.photo":
               img_url = msg_obj.content.href.replace("\\/", "/")
               img_url = urllib.parse.unquote(img_url)
               last_sent_image_url = img_url
               send_image_link(img_url, thread_id, thread_type)
            elif msg_obj.quote:
                attach = msg_obj.quote.attach
                if attach:
                    try:
                        attach_data = json.loads(attach)
                    except json.JSONDecodeError as e:
                        print(f"Lỗi khi phân tích JSON: {str(e)}")
                        return

                    image_url = attach_data.get('hdUrl') or attach_data.get('href')
                    if image_url:
                        self.sendMessage(Message(text=image_url), thread_id=thread_id, thread_type=thread_type)
                    else:
                        self.sendMessage(Message(text='Bug code null'), thread_id=thread_id, thread_type=thread_type)
                else:
                    self.sendMessage(Message(text='Xem lại code đê bug rồi'), thread_id=thread_id, thread_type=thread_type)
            else:
                self.sendMessage(Message(text='Bug code null'), thread_id=thread_id, thread_type=thread_type)
        elif message.startswith(self.prefix+"scl"):
           prefix_match = re.match(r"^(\W+)", message)
           if prefix_match:
               self.prefix = prefix_match.group(1)

           content = message[len(self.prefix):].strip().split()

           if len(content) == 2 and content[0].lower() == "scl" and content[1].isdigit():
               return self.handle_selection(content[1], message_object, thread_id, thread_type, author_id)

           if len(content) < 2:
               self.replyMessage(
                   Message(text=f"• Vui lòng nhập {self.prefix}scl [tên bài hát]."),
                   message_object, thread_id, thread_type, ttl=30000)
               return

           keyword = ' '.join(content[1:])
           search_results = self.find_with_keyword(keyword)
 
           if not search_results:
               self.replyMessage(
                   Message(text="• Không tìm thấy kết quả nào"),
                   message_object, thread_id, thread_type, ttl=30000)
               return

           self.process_music_collection(search_results, thread_id, thread_type, message_object)
        elif message.startswith(self.prefix+"add"):
            with open('admin.json', 'r+') as admin_file:
                try:
                    admin_data = json.load(admin_file)
                except json.JSONDecodeError:
                    admin_data = {"idadmin": []}
            idadmin = set(admin_data.get("idadmin", []))
            if author_id not in idadmin:
                self.replyMessage(
                    Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'),
                    message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000
                )
                return
            parts = message.split()
            if len(parts) < 2:
                self.replyMessage(
                    Message(text='⚠️ Vui lòng cung cấp ít nhất 1 UID để thêm.'),
                    message_object, thread_id=thread_id, thread_type=thread_type
                )
                return
            new_ids = set(parts[1:])
            added_ids = new_ids - idadmin
            if not added_ids:
                self.replyMessage(
                    Message(text="ℹ️ Tất cả UID đã có sẵn trong danh sách admin."),
                    message_object, thread_id, thread_type
                )
                return
            added_msg = []
            for uid in added_ids:
                user_info = self.fetchUserInfo(uid) 
                user_data = user_info.changed_profiles.get(str(uid), {})
                display_name = user_data.get("displayName", f"UID {uid}") 
                added_msg.append(display_name)
            formatted_names = ", ".join(added_msg)
            added_msg.append(f"Đã thêm: {formatted_names} UID {uid} vào danh sách admin.")
            idadmin.add(uid)
            with open('admin.json', 'w') as admin_file:
                json.dump({"idadmin": list(idadmin)}, admin_file, indent=4)
            current_list = "\n".join(f"• {uid}" for uid in idadmin)
            full_msg = "\n".join(added_msg) + f"\n\nDanh sách UID admin hiện tại:\n{current_list}"
            self.replyMessage(
                Message(text=full_msg),
                message_object, thread_id, thread_type
            )   
        elif message.startswith(self.prefix+"voice"):
            try:
                content = message_object.content.strip()
                command_parts = content.split(maxsplit=1)
                text = command_parts[1].strip() if len(command_parts) > 1 else ""
                if not text:
                    self.sendMessage(Message(text='Nhập hộ bố nội dung'), thread_id=thread_id, thread_type=thread_type)
                    return

                filepath = self.convert_text_to_mp3(text)
                if filepath:
                    voice_url = self.uploadzvoice(filepath)
                    if voice_url:
                        file_size = os.path.getsize(filepath)
                        path2 = '.aac'
                        voice_link = voice_url+path2
                        self.sendRemoteVoice(voice_link, thread_id, thread_type, fileSize=file_size)
                    else:
                        self.sendMessage(Message(text='bug con cu'), thread_id=thread_id, thread_type=thread_type)
                else:
                    self.sendMessage(Message(text='bug con cặc'), thread_id=thread_id, thread_type=thread_type)
            except Exception as e:
                print(f"❌ Lỗi upload {e}")
                return None
        elif message.startswith(self.prefix+"acpfr"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo.get('idadmin', []))
            if author_id not in idadmin:
                return
            try:
                parts = message.split()
                if len(parts) < 3:
                    self.replyMessage(
                        Message(text="ᴜꜱᴇ ᴀᴄᴘꜰʀ ᴜɪᴅ ɢʀᴏᴜᴘ ɪᴅ"),
                        message_object, thread_id=thread_id, thread_type=thread_type,
                        ttl=30000
                    )
                    return
                uiduser = parts[1]
                group_id = parts[2]
                user_names = []
                self.sendMessage(Message(text=f"Đã gửi yêu cầu kết bạn tới người dùng có uid {uiduser}"), thread_id=thread_id, thread_type=thread_type)
                self.sendrqsfriend(uiduser, group_id)
            except Exception as e:
                logging.error(f"Lỗi trong acpfr: {e}")      
        elif message.startswith(self.prefix+"flood"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo.get('idadmin', []))

            if author_id not in idadmin:
                return

            args = message.strip().split()
            if len(args) == 1:
                self.sendMessage(Message(text='🚫 𝙐𝙨𝙚:\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙛𝙛\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙣 𝘿𝙚𝙡𝙖𝙮'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return

            if args[1].lower() == "off":
                self.dungFlood()  
                self.sendMessage(Message(text='✅ 𝙎𝙩𝙤𝙥 𝙁𝙡𝙤𝙤𝙙 𝙎𝙪𝙘𝙘𝙚𝙨𝙨 !'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return

            if args[1].lower() == "on":
                if len(args) < 3 or not args[2].isdigit():
                    self.sendMessage(Message(text='🚫 𝙐𝙨𝙚:\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙛𝙛\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙣 𝘿𝙚𝙡𝙖𝙮'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
                    return

                try:
                    delay = float(args[2].strip())
                    if delay < 0:
                        self.sendMessage(Message(text='🚫 𝙃𝙤𝙬 𝙏𝙤 𝘿𝙚𝙡𝙖𝙮 ?'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
                        return

                    with open('Quyt.txt', 'r') as file:
                        flood_text = file.readlines()
                        flood_text = [line.strip() for line in flood_text if line.strip()]

                    group = self.fetchGroupInfo(thread_id)
                    group_info = group.get("gridInfoMap", {}).get(thread_id, {})
                    mem_ver_list = group_info.get('memVerList', [])
                    cleaned_list = [item.replace('_0', '') for item in mem_ver_list]

                    mentions = [Mention(user_id, offset=0, length=3000, auto_format=False) for user_id in cleaned_list]
                    cc = MultiMention(mentions)

                    while True:
                        word = random.choice(flood_text)
                        self.send(Message(text=str(word), mention=cc), thread_id, thread_type)
                        time.sleep(delay)

                except ValueError:
                    self.sendMessage(Message(text='🚫 𝙄𝙣𝙘𝙤𝙧𝙧𝙚𝙘𝙩 𝙐𝙨𝙖𝙜𝙚 !\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙛𝙛\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙣 𝘿𝙚𝙡𝙖𝙮'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
        elif message.startswith(self.prefix+"send"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            parts = message.split(" ", 2)
            if len(parts) < 2:
                self.replyMessage(
                    Message(text="⚠️ Vui lòng cung cấp UID nhóm !"), 
                    message_object, thread_id, thread_type
                )
                return
            group_id = parts[1].strip()
            text = parts[2].strip()
            self.send(Message(text=f'{text}'), thread_id=group_id, thread_type=ThreadType.GROUP)
        elif message.startswith(self.prefix+"msg"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            parts = message.split(" ", 2)
            if len(parts) < 2:
                self.replyMessage(
                    Message(text="⚠️ Vui lòng cung cấp UID user !"), 
                    message_object, thread_id, thread_type
                )
                return
            group_id = parts[1].strip()
            text = parts[2].strip()
            self.send(Message(text=f'{text}'), thread_id=group_id, thread_type=ThreadType.USER)
        elif message.startswith(self.prefix+"join"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            try:
                parts = message.split(" ", 1)
                if len(parts) < 2:
                    self.replyMessage(
                        Message(text="⚠️ Vui lòng cung cấp link nhóm !"), 
                        message_object, thread_id, thread_type
                    )
                    return
                url = parts[1].strip()
                if not url.startswith("https://zalo.me/"):
                    self.replyMessage(
                        Message(text="⛔ Link không hợp lệ! Link phải bắt đầu bằng https://zalo.me/"), 
                        message_object, thread_id, thread_type
                    )
                    return
                join_result = self.joinGroup(url)
                if not join_result:
                   self.replyMessage(Message(text='Không thể tham gia nhóm'), thread_id=thread_id, thread_type=thread_type)
                group_info = self.getiGroup(url)
                if not isinstance(group_info, dict) or 'groupId' not in group_info:
                    raise ZaloAPIException("Không thể lấy thông tin nhóm")
                group_id = group_info['groupId']
                print(f"A {group_id}")
                self.send(Message(text=f'Group ID {group_id}'), thread_id=thread_id, thread_type=thread_type)
            except Exception as e:
                   self.replyMessage(
                       Message(text=f"❌ Lỗi: {str(e)}"),
                       message_object, thread_id, thread_type
                   )
        elif message.startswith(self.prefix+"all"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            try:
                parts = message.split(" ", 1)
                if len(parts) < 2:
                    self.replyMessage(Message(text="🚫 𝑈𝑠𝑒:\nAllV3 𝑡𝑒𝑥𝑡_𝑎𝑙𝑙"), 
                                     message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                    return  
                text_all = parts[1].strip()
                mentions = []
                group = self.fetchGroupInfo(thread_id)
                group_info = group.gridInfoMap[thread_id]
                mem_ver_list = group_info['memVerList']
                cleaned_list = [item.replace('_0', '') for item in mem_ver_list]
                for user_id in cleaned_list:
                    mentions.append(Mention(user_id, offset=0, length=3000, auto_format=False))
                    time.sleep(0.00001)
                cc = MultiMention(mentions)
                self.send(Message(text=str(text_all), mention=cc), thread_id, thread_type)   
            except Exception as e:
                logging.error(f"Lỗi trong AllV3: {e}")      
        elif message.startswith(self.prefix+"call"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            if author_id == '4144778287926415791':
                self.sendMessage(Message(text='You Are BlackList !'), thread_id=thread_id, thread_type=thread_type)
                return
            try:
                parts = message.split()
                if len(parts) < 3:
                    self.replyMessage(
                        Message(text="ᴜꜱᴇ ᴄᴀʟʟ ᴜɪᴅ1 ᴜɪᴅ2 ᴜɪᴅ3 ... ᴄᴏᴜɴᴛ"),
                        message_object, thread_id=thread_id, thread_type=thread_type,
                        ttl=30000
                    )
                    return
                target_ids = parts[1:-1]
                call_count = int(parts[-1])
                user_names = []
                for uid in target_ids:
                    user_info = self.fetchUserInfo(uid) 
                    user_data = user_info.changed_profiles.get(str(uid), {})
                    display_name = user_data.get("displayName", f"UID {uid}") 
                    user_names.append(display_name)
                formatted_names = ", ".join(user_names)
                self.replyMessage(Message(text=f'''
┌─────────────────>
├>•ʙᴏᴛ ꜱᴘᴀᴍ ᴄᴀʟʟ ᴠɪᴘ
├•ꜱᴘᴀᴍ ᴄᴀʟʟ ꜱᴇɴᴛ ᴛᴏ:
├•ᴜꜱᴇʀ ɪᴅ: {formatted_names}
├•ᴄᴀʟʟ: {call_count}
├>•ᴅᴜᴏɴɢ ɴɢᴏᴄ ʏᴇᴜ ǫᴜʏ̀ɴʜ ᴀɴʜ      
└─────────────────>'''), message_object, thread_id=thread_id, thread_type=thread_type)
                for target_id in target_ids:
                    threading.Thread(target=self.StartCall, args=(target_id, call_count), daemon=True).start()
            except Exception as e:
                print(f"Lỗi: {e}")
        elif message.startswith(self.prefix+"info"):
            user_id = None
            if message_object.mentions:
                user_id = message_object.mentions[0]['uid']
            elif content[5:].strip().isnumeric():
                user_id = content[5:].strip()
            else:
                user_id = author_id
            user_info = self.fetchUserInfo(user_id)
            infozalo = self.checkinfo(user_id, user_info, thread_id)
            self.replyMessage(Message(text=infozalo, parse_mode="HTML"), message_object, thread_id=thread_id, thread_type=thread_type)
        elif message.lower().startswith(self.prefix+"cnt"):
            try:
                result = subprocess.run(["ping", "-c", "1", "google.com"], capture_output=True, text=True)
                for line in result.stdout.split("\n"):
                    if "time=" in line:
                        ping_time = line.split("time=")[-1].split(" ")[0]
                        self.replyMessage(Message(text=f'''
┌─────────────────>
├>•ᴛᴇꜱᴛ ᴘɪɴɢ ᴡɪꜰɪ ᴏʀ 𝟦ɢ
├•📶 ʏᴏᴜʀ ᴘɪɴɢ: {ping_time} ᴍꜱ
├•ʙᴏᴛ ᴢᴀʟᴏ ᴄᴏᴅᴇ ᴏꜰ ᴅᴜᴏɴɢ ɴɢᴏᴄ
├>•ᴅᴜᴏɴɢ ɴɢᴏᴄ ʏᴇᴜ ǫᴜʏ́ᴛ - ᴛᴍɪᴇᴇ
└─────────────────>'''), message_object, thread_id=thread_id, thread_type=thread_type)
                        return
                self.replyMessage(Message(text='''
┌─────────────────>
├>•ᴛᴇꜱᴛ ᴘɪɴɢ ᴡɪꜰɪ ᴏʀ 𝟦ɢ
├•📶 ʏᴏᴜʀ ᴘɪɴɢ: ʏᴏᴜʀ ᴡɪꜰɪ ᴏʀ 𝟦ɢ ᴅɪꜱᴄᴏɴɴᴇᴄᴛ ᴏʀ ʙᴏᴛ ʙᴜɢ ⚠️
├•ʙᴏᴛ ᴢᴀʟᴏ ᴄᴏᴅᴇ ᴏꜰ ᴅᴜᴏɴɢ ɴɢᴏᴄ
├>•ᴅᴜᴏɴɢ ɴɢᴏᴄ ʏᴇᴜ ǫᴜʏ́ᴛ - ᴛᴍɪᴇᴇ
└─────────────────>'''), message_object, thread_id=thread_id, thread_type=thread_type) 
            except Exception as e:
                self.replyMessage(Message(text='⚠️ ᴅɪꜱᴄᴏɴɴᴇᴄᴛ!'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
        elif message.startswith(self.prefix+"spam"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            args = content.split()
            if len(args) >= 3:
                message = " ".join(args[1:-1])
                try:
                    delay = float(args[-1])
                    if delay < 0:
                        self.replyMessage(Message(text='🚫 𝙃𝙤𝙬 𝙏𝙤 𝘿𝙚𝙡𝙖𝙮 ?'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                        return
                    self.chayspam(message, delay, thread_id, thread_type)
                except ValueError:
                    self.replyMessage(Message(text='🚫 𝙋𝙡𝙚𝙖𝙨𝙚 𝙄𝙣𝙥𝙪𝙩 𝘿𝙚𝙡𝙖𝙮'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
            else:
                self.replyMessage(Message(text='🚫 𝙐𝙨𝙚:\n𝙎𝙥𝙖𝙢 𝙏𝙚𝙭𝙩 𝘿𝙚𝙡𝙖𝙮\n\n𝑺𝒑𝒂𝒎 𝑵𝒈𝒐𝒄 𝟓'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
        elif message.startswith(self.prefix+"stp"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            self.dungspam()
            self.replyMessage(Message(text='𝙎𝙩𝙤𝙥 𝙎𝙥𝙖𝙢 𝙎𝙪𝙘𝙘𝙚𝙨𝙨 !'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
        elif message.startswith(self.prefix+"off"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            self.replyMessage(Message(text='𝙊𝙛𝙛 ! - 𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝙁𝙪𝙡𝙡'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
            exit()
    def QuynhAnhXinh(self, thread_id, user_id):
        group_info = self.fetchGroupInfo(groupId=thread_id)
        admin_ids = group_info.gridInfoMap[thread_id]['adminIds']
        creator_id = group_info.gridInfoMap[thread_id]['creatorId']
        return user_id in admin_ids or user_id == creator_id
    def spam_message(self, spam_content, thread_id, thread_type):
        """Spam the content from content.txt file in the thread."""
        words = spam_content.split()
        while self.spamming:
            for word in words:
                if not self.spamming:
                    break
                mention = Mention(uid='-1', offset=0, length=len(word))
                spam_message = Message(text=word, mention=mention)
                self.send(spam_message, thread_id=thread_id, thread_type=thread_type)
                time.sleep(0.5)

    def chayspam(self, message, delay, thread_id, thread_type):
        if self.spamming:
            self.dungspam()
        self.spamming = True
        self.spam_thread = threading.Thread(target=self.spamtagall, args=(message, delay, thread_id, thread_type))
        self.spam_thread.start()
    def dungspam(self):
        if self.spamming:
            self.spamming = False
            if self.spam_thread is not None:
                self.spam_thread.join()
            self.spam_thread = None
    def get_file_type(self, file_url):
        try:
            response = requests.head(file_url, allow_redirects=True, timeout=10)
            content_type = response.headers.get("Content-Type", "")
            if "video" in content_type:
                return "video"
            else:
                return "unknown"
        except requests.RequestException:
            print("❌ Không thể xác định loại file.")
            return "unknown"
    def convert_mp4_to_webp_and_upload(self, video_path):
        try:
            response = requests.get(video_path, stream=True)
            response.raise_for_status()
            temp_mp4 = "temp_video.mp4"
            filepath = "temp_sticker.webp"
            with open(temp_mp4, "wb") as f:
                for chunk in response.iter_content(1024):
                    f.write(chunk)
            subprocess.run([
                "ffmpeg", "-y", "-i", temp_mp4,
                "-vf", "scale=512:-1",
                "-loop", "0",
                "-r", "15",
                "-an",
                "-loglevel", "error",
                filepath
            ], stderr=subprocess.DEVNULL, check=True)
            upload_url = self.uploadzcloud(filepath=filepath, toid=self._state._config.get('cloud_id'))
            os.remove(temp_mp4)
            os.remove(filepath)
            return upload_url
        except Exception as e:
            print(f"❌ Lỗi khi chuyển MP4 sang WebP: {e}")
            return None
    def load_mutenguoidung(self):
        try:
            with open('mute.json', 'r') as mute_file:
                data = json.load(mute_file)
                if isinstance(data, dict):
                    return set(data.get('mutenguoidung', []))
                elif isinstance(data, list):
                    return set(data)
                else:
                    return set()
        except (FileNotFoundError, json.JSONDecodeError):
            return set()

    def save_mutenguoidung(self, mutenguoidung):
        with open('mute.json', 'w') as mute_file:
            json.dump({'mutenguoidung': list(mutenguoidung)}, mute_file)
    def get_url_down(self, progressive_url):
        params = {"client_id": "KKzJxmw11tYpCs6T24P4uUYhqmjalG6M"}
        try:
            response = requests.get(progressive_url, headers=self.headers, params=params)
            response.raise_for_status()
            response_json = response.json()
            check = response_json.get('data', None)
            if check:
                url = check.get('url', None)
            else:
                url = response_json.get('url', None)
            return url if url else False
        except requests.RequestException as e:
            print(f"Error in get_url_down: {e}")
            return False
    def find_with_keyword(self, keyword):
        params = {
            'q': keyword,
            'client_id': 'KKzJxmw11tYpCs6T24P4uUYhqmjalG6M',
            'stage': '',
        }
        try:
            response = requests.get('https://api-mobi.soundcloud.com/search', params=params, headers=self.headerscl).json()
            return response
        except requests.RequestException as e:
            print(f"Error in find_with_keyword: {e}")
            return False

    def convertMillis(self, millis):
        millis = int(millis)
        seconds = int(millis / 1000) % 60
        minutes = int(millis / (1000 * 60)) % 60
        hours = int(millis / (1000 * 60 * 60))
        return f'{hours}:{minutes}:{seconds}'
        
    def get_and_upload_url(self, progressive_url):
        file_name = 'qanh.aac'
        url_holder = {"url": None}
        try:
            response = requests.get(progressive_url, headers=self.headerscl, params={"client_id": "KKzJxmw11tYpCs6T24P4uUYhqmjalG6M"})
            response.raise_for_status()
            response_json = response.json()
            check = response_json.get('data', None)
            url_holder["url"] = check.get('url') if check else response_json.get('url')
            if not url_holder["url"]:
                print("Không tìm thấy URL .aac.")
                return False
        except Exception as e:
            print(f"❌ Lỗi lấy URL progressive: {e}")
            return False
        success_flag = {"done": False, "error": False}
        def _download():
            try:
                audio = requests.get(url_holder["url"], timeout=10).content
                with open(file_name, "wb") as f:
                    f.write(audio)
                success_flag["done"] = True
            except Exception as e:
                print(f"❌ Lỗi tải file .aac: {e}")
                success_flag["error"] = True

        threading.Thread(target=_download, daemon=True).start()
        start = time.time()
        while not success_flag["done"] and not success_flag["error"]:
            if time.time() - start > 150:
                print("⏱️ Quá hạn tải file.")
                return False
            time.sleep(0.2)
        if not os.path.exists(file_name):
            print("❌ File không tồn tại.")
            return False
        try:
            if os.path.getsize(file_name) > 3 * 1024 * 1024:
                voice_url = self.uploadzothers(filepath=file_name)
            else:
                voice_url = self.uploadzvoice(filepath=file_name)
            os.remove(file_name)
            return voice_url
        except Exception as e:
            print(f"❌ Lỗi upload file: {e}")
            return False
            
    def _handle_vdstk_async(self, attach_json, thread_id, thread_type, message_object):
        try:
            attach_data = json.loads(attach_json)
            file_url = attach_data.get("hdUrl") or attach_data.get("href")
            if not file_url:
                self.replyMessage(Message(text="❌ Không tìm thấy URL video."), message_object, thread_id, thread_type)
                return

            file_url = file_url.replace("\\/", "/")
            file_url = urllib.parse.unquote(file_url)

            if self.get_file_type(file_url) != "video":
                self.replyMessage(Message(text="❌ File không phải video."), message_object, thread_id, thread_type)
                return

            webp_url = self.convert_mp4_to_webp_and_upload(file_url)
            if not webp_url:
                self.replyMessage(Message(text="❌ Không tạo được sticker từ video."), message_object, thread_id, thread_type)
                return
            self.sendCustomSticker(animationImgUrl=webp_url, staticImgUrl=webp_url, thread_id=thread_id, thread_type=thread_type, reply=message_object, width=None, height=None)
            send_message = "✅ Đã tạo Sticker [ V2 ] thành công !"
            style = MultiMsgStyle([
                MessageStyle(offset=0, length=len(send_message), style="font", size="6", auto_format=False),
                MessageStyle(offset=0, length=len(send_message), style="bold", auto_format=False)
            ])
            styled_message = Message(text=send_message, style=style)
            self.replyMessage(styled_message, message_object, thread_id, thread_type)
        except json.JSONDecodeError:
            self.replyMessage(Message(text="❌ Lỗi khi phân tích JSON file đính kèm."), message_object, thread_id, thread_type)
        except Exception as e:
            print(f"[vdstk] Lỗi xử lý video: {e}")
            self.replyMessage(Message(text="❌ Gặp lỗi khi xử lý video."), message_object, thread_id, thread_type)

    def convert_text_to_mp3(self, text):
        try:
            tts = gTTS(text=text, lang='vi')
            mp3_file = 'dngoc.acc'
            tts.save(mp3_file)
            return mp3_file
        except Exception as e:
            print(f"Lỗi {str(e)}")
            return None
    def spamtagall(self, message, delay, thread_id, thread_type):
        while self.spamming:
            try:
                logging.debug(f"Sending message: {message}, thread_id: {thread_id}, thread_type: {thread_type}")
                message_obj = Message(text=message)
                self.send(message_obj, thread_id=thread_id, thread_type=thread_type, ttl=500)
                time.sleep(delay)
            except Exception as e:
                logging.error(f"Error during spamtagall: {e}")
                break

    def spambroad(self, toUid, count):
        def _run_broad():
            self.broad_running = True
            futures = []
            for i in range(int(count)):
                if not self.broad_running:
                    break
                futures.append(
                    self.thread_pool.submit(
                        self.broadsp,
                        toUid
                    )
                )
                time.sleep(0)
            for future in futures:
                future.result()
            self.broad_running = False
        threading.Thread(target=_run_broad, daemon=True).start()

    def getNameFromUID(self, uid):
        try:
            user_info = self.fetchUserInfo(uid)
            uid_str = str(uid)
            if hasattr(user_info, "changed_profiles"):
                profile = user_info.changed_profiles.get(uid_str)
                if profile:
                    return profile.get("displayName", "Không rõ")
            elif isinstance(user_info, dict):
                return user_info.get("display_name", "Không rõ")
        except Exception as e:
            print(f"⚠️ Lỗi khi lấy tên người dùng {uid}: {e}")
        return "Không rõ"

    def process_music_collection(self, search_results, thread_id, thread_type, message_object):
        collection = search_results['collection']
        collection = [x for x in collection if list(x.keys())[0] != 'avatar_url']
        response_text = ''

        self.user_datascl[thread_id] = []
        for idx, data in enumerate(collection):
            media_info = data.get('media', {}).get('transcodings', [])
            if not media_info:
                continue

            title = data['title']
            duration = data['duration']
            link = next((media['url'] for media in media_info if media['format']['protocol'] == 'progressive'), None)
            artwork_url = data.get('artwork_url', '')
            artist = data.get('user', {}).get('username', 'Unknown Artist')

            response_text += f'{idx + 1} • {title} || {self.convertMillis(duration)}\n'
            self.user_datascl[thread_id].append({'link': link, 'duration': duration, 'title': title, 'artwork_url': artwork_url, 'artist': artist})

        self.replyMessage(Message(text=response_text), message_object, thread_id, thread_type, ttl=30000)
        self.replyMessage(
            Message(text=f"• Nhập `{self.prefix}scl <số>` để chọn bài hát."),
            message_object, thread_id, thread_type, ttl=30000)

        self.next_stepscl[thread_id] = 'wait_select'

    def handle_selection(self, message_content, message_object, thread_id, thread_type, author_id):
        
        if thread_id not in self.next_stepscl or self.next_stepscl[thread_id] != 'wait_select':
            return  

        if thread_id not in self.user_datascl or not self.user_datascl[thread_id]:
            self.replyMessage(
                Message(text="• Không có danh sách bài hát để chọn. Vui lòng tìm kiếm lại."),
                message_object, thread_id, thread_type, ttl=30000)
            return

        if message_object and message_object.quote:
            selected_text = message_object.quote.msg.strip().lower()
            for idx, song in enumerate(self.user_datascl[thread_id]):
                if song['title'].strip().lower() in selected_text:
                    number = idx
                    break
            else:
                raise ValueError("Không tìm thấy bài hát được reply")
        else:
            number = int(''.join(filter(str.isdigit, message_content))) - 1

        if number < 0 or number >= len(self.user_datascl[thread_id]):
            raise ValueError("Số không hợp lệ")

        selected_song = self.user_datascl[thread_id][number]
        url_down = selected_song['link']
        duration = selected_song['duration']
        title = selected_song['title']
        artwork_url = selected_song['artwork_url']
        artist = selected_song['artist']

        if duration > 120 * 800 * 1000:  
            self.replyMessage(
                Message(text="• Chọn bài hát có thời lượng dưới 120 phút."),
                message_object, thread_id, thread_type, ttl=30000)
            return

        self.replyMessage(
            Message(text="• Đang tải bài hát, vui lòng đợi..."), message_object, thread_id, thread_type, ttl=30000)
        threading.Thread(
            target=self._voice_async_upload_and_send,
            args=(url_down, thread_id, thread_type, title, artist, duration, message_object),
            daemon=True
        ).start()
        
    def _voice_async_upload_and_send(self, url, thread_id, thread_type, title, artist, duration, message_object):
        try:
           voice_url = self.get_and_upload_url(url)
           if not voice_url:
               self.replyMessage(
                   Message(text="❌ Không thể tải hoặc upload bài hát."),
                   message_object, thread_id, thread_type, ttl=30000)
               return

           voice_url2 = voice_url + '.aac'
           self.sendRemoteVoice(voice_url2, thread_id, thread_type)
           img_stk = random.choice([
                   "https://f34-zfcloud.zdn.vn/c99ab6400472a52cfc63/7612735201097498885",
                   "https://f33-zfcloud.zdn.vn/cb0685d137e396bdcff2/757835088741067321"
               ])
           self.sendCustomSticker(animationImgUrl=img_stk, staticImgUrl=img_stk, thread_id=thread_id, thread_type=thread_type, reply=message_object, width=None, height=None)
           self.sendMessage(Message(text=f'''
├>•ʙᴏᴛ ꜱᴏᴜɴᴅ ᴏɴ ᴄʟᴏᴜᴅ
•ᴍᴜꜱɪᴄ ꜱᴏᴜɴᴅ ꜰᴏʀ ʏᴏᴜ
•ɴᴀᴍᴇ ꜱᴏɴɢ: {title}
•ᴀʀᴛɪꜱᴛ ꜱᴏɴɢ: {artist}
•ᴅᴜʀᴀᴛɪᴏɴ: {self.convertMillis(duration)}
├>•ᴅᴜᴏɴɢ ɴɢᴏᴄ ʏᴇᴜ ǫᴜʏ̀ɴʜ ᴀɴʜ            
'''), thread_id=thread_id, thread_type=thread_type)

        except Exception as e:
            print(f"❌ Lỗi gửi voice async: {e}")
            self.sendMessage(Message(text="❌ Lỗi khi gửi voice"), thread_id=thread_id, thread_type=thread_type)

        finally:
            self.next_stepscl.pop(thread_id, None)
            self.user_datascl.pop(thread_id, None)
    
    def find_with_keyword_youtube(self, keyword):
        url = "https://www.googleapis.com/youtube/v3/search"
        params = {
            "part": "snippet",
            "q": keyword,
            "type": "video",
            "maxResults": 15,
            "key": self.youtube_api_key
        }
        try:
            res = requests.get(url, params=params).json()
            results = []
            for item in res.get("items", []):
                video_id = item["id"]["videoId"]
                snippet = item["snippet"]
                title = snippet.get("title", "Không tiêu đề")
                channel = snippet.get("channelTitle", "Không rõ")
                thumbnail = snippet["thumbnails"]["high"]["url"]
                results.append({
                    "id": video_id,
                    "title": title,
                    "channel": channel,
                    "thumbnail": thumbnail,
                    "duration": "unknown"
                })
            return results
        except Exception as e:
            print(f"❌ Lỗi tìm kiếm YT API: {e}")
            return []

    def process_youtube_collection(self, search_results, thread_id, thread_type, message_object):
        self.user_datayt[thread_id] = search_results
        self.next_stepyt[thread_id] = "wait_select"

        result_text = ""
        for idx, data in enumerate(search_results):
            result_text += f"{idx + 1} • {data['title']} || {data['channel']}\n"

        self.replyMessage(Message(text=result_text), message_object, thread_id, thread_type, ttl=30000)
        self.replyMessage(
            Message(text=f"• Nhập `{self.prefix}yt <số>` để chọn bài hát."),
            message_object, thread_id, thread_type, ttl=30000)

    def handle_selection_yt(self, message_content, message_object, thread_id, thread_type):
        if thread_id not in self.next_stepyt or self.next_stepyt[thread_id] != 'wait_select':
            return  

        if thread_id not in self.user_datayt or not self.user_datayt[thread_id]:
            self.replyMessage(
                Message(text="• Không có danh sách bài hát để chọn. Vui lòng tìm kiếm lại."),
                message_object, thread_id, thread_type, ttl=30000)
            return

        try:
            number = int(''.join(filter(str.isdigit, message_content))) - 1
        except:
            self.replyMessage(Message(text="❌ Số không hợp lệ!"), message_object, thread_id, thread_type)
            return

        if number < 0 or number >= len(self.user_datayt[thread_id]):
            self.replyMessage(Message(text="❌ Số không hợp lệ!"), message_object, thread_id, thread_type)
            return

        selected = self.user_datayt[thread_id][number]
        video_id = selected["id"]
        video_url = f"https://www.youtube.com/watch?v={video_id}"
        title = selected["title"]
        duration = selected.get("duration", "unknown")
        channel = selected.get("channel", "Không rõ")

        self.replyMessage(
            Message(text="• Đang tải bài hát, vui lòng đợi..."), message_object, thread_id, thread_type, ttl=30000)

        threading.Thread(
            target=self.yt_thread_download_and_send,
            args=(video_url, thread_id, thread_type, title, duration, message_object, channel),
            daemon=True
        ).start()

    def yt_thread_download_and_send(self, video_url, thread_id, thread_type, title, duration, message_object, channel):
        try:
            filepath = self.download_audio_from_youtube(video_url)
            if not filepath:
                self.replyMessage(
                    Message(text="❌ Không thể tải file audio."),
                    message_object, thread_id, thread_type, ttl=30000)
                return

            size = os.path.getsize(filepath)
            if size > 5 * 1024 * 1024:
                voice_url = self.uploadzothers(filepath=filepath)
            else:
                voice_url = self.uploadzvoice(filepath=filepath)

            os.remove(filepath)

            if voice_url:
                self.sendRemoteVoice(voice_url + ".aac", thread_id, thread_type)
                self.sendMessage(Message(text=f'''
├>• 𝚈𝙾𝚄𝚃𝚄𝙱𝙴 𝚅𝙾𝙸𝙲𝙴 𝙱𝙾𝚃
• 𝚃𝚒𝚝𝚕𝚎: {title}
• 𝙲𝚑𝚊𝚗𝚗𝚎𝚕: {channel}
├>• 𝙳𝚄𝙾𝙽𝙶 𝙽𝙶𝙾𝙲 𝚈𝙴̂𝚄 𝚀𝚄𝚈̀𝙽𝙷 𝙰𝙽𝙷 ❤️
'''), thread_id=thread_id, thread_type=thread_type)
            else:
                self.replyMessage(
                    Message(text="❌ Upload thất bại."), message_object, thread_id, thread_type)

        except Exception as e:
            print(f"❌ Lỗi trong yt_thread_download_and_send: {e}")
            self.replyMessage(
                Message(text="❌ Gặp lỗi trong quá trình gửi voice."),
                message_object, thread_id, thread_type)

        finally:
            self.user_datayt.pop(thread_id, None)
            self.next_stepyt.pop(thread_id, None)

    def download_audio_from_youtube(self, video_url):
        try:
            cmd = [
                "yt-dlp",
                "-f", "bestaudio[ext=m4a]/bestaudio",
                "-g", video_url
            ]
            direct_url = subprocess.check_output(cmd).decode().strip()
            output_file = "qanh_yt.aac"
            cmd2 = [
                "aria2c",
                "-x", "16", "-s", "16",
                "-o", output_file,
                direct_url
            ]
            subprocess.run(cmd2, check=True)
            return output_file if os.path.exists(output_file) else None
        except Exception as e:
            print(f"❌ Lỗi tải yt: {e}")
            return None
        
    def checkinfo(self, user_id, user_info, thread_id):
        if 'changed_profiles' in user_info and user_id in user_info['changed_profiles']:
            profile = user_info['changed_profiles'][user_id]
            infozalo = f'''
> ┌─────────────────────
> ├> <b>ɴᴀᴍᴇ: </b> {profile.get('displayName', '')}
> ├> <b>ɪᴅ-ᴜꜱᴇʀ: </b> {profile.get('userId', '')}
> ├> <b>ɪᴅ-ɢʀᴏᴜᴘ: </b> {thread_id}
> └─────────────────────
        '''
            return infozalo
        else:
            return "Thông tin không tồn tại."
    
client = QuynhAnh(
    '</>', '</>',
    imei="9a10cdb1-33d7-4e10-8fec-c326ee27e7fa-b78b4e2d6c0a362c418b145fe44ed73f",
    user_agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    session_cookies={"_ga":"GA1.2.462174354.1735137725","ozi":"2000.QOBlzDCV2uGerkFzm09Jrc3NuFp21bJLAj3c-ei6KD4eqE7zCJ0.1","_ga_RYD7END4JE":"GS1.2.1743655746.1.0.1743655746.60.0.0","__zi":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8WzaUsYdq5TYdUNxwNMGLcETPVeeZ4m.1","__zi-legacy":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8WzaUsYdq5TYdUNxwNMGLcETPVeeZ4m.1","zpsid":"ocw7.438066754.2.y93HeSr9a0EF5umPmKcG0xWwuZV-SQ0r-twbDyFsf9h_kBAYpEypHgL9a0C","zpw_sek":"c3EE.438066754.a0.Iq83XyCmdcQ1Re9yuZ2UPhWI-mtX2hm-w43G1B16zmkg0jWBybNe3ga0nnUa3QD4lZuXKbe2RqHYCJd5XbYUPW","_zlang":"vn","app.event.zalo.me":"9145091260981033568"})
client.listen()