from zlapi import ZaloAPI, ZaloAPIException
from zlapi.models import *
from zlapi import Message, ThreadType, Mention, MessageStyle, MultiMsgStyle
from concurrent.futures import ThreadPoolExecutor
import time
import mimetypes
from time import sleep 
from datetime import datetime
import threading
import random
import subprocess
from Crypto.Cipher import AES
import base64
import logging
import json
import re
import urllib.parse
from catool import MusicDownloader
import os
import requests
from PIL import Image, ImageDraw
from io import BytesIO
from zlapi.models import Message, MultiMsgStyle, MessageStyle
from zlapi._threads import ThreadType

def Tcp_Focx():
    try:
        with open('admin.json', 'r') as adminvip:
            adminzalo = json.load(adminvip)
            return set(adminzalo.get('idadmin', []))
    except FileNotFoundError:
        return set()
idadmin = Tcp_Focx()
class QuynhAnh(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = ".."
        self.spamming = False
        self.spam_thread = None
        self.spammingvip = False
        self.spam_threadvip = None
        self.next_stepscl = {}  
        self.user_datascl = {}  
        self.music_downloader = MusicDownloader()
        self.idnguoidung = ['685820883407282350']
        self.excluded_user_ids = []
        self.call_running = False
        self.successful_call = 0
        self.todo_running = False
        self.successful_todos = 0
        self.thread_pool = ThreadPoolExecutor(max_workers=100000000)
        self.imei = kwargs.get('imei')
        self.session_cookies = kwargs.get('session_cookies')
        self.secret_key = self.getSecretKey()
        self.headers = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "sec-ch-ua": "\"Not-A.Brand\";v=\"99\", \"Chromium\";v=\"124\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Linux\"",
            "origin": "https://chat.zalo.me",
            "sec-fetch-site": "same-site",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "Accept-Encoding": "gzip",
            "referer": "https://chat.zalo.me/",
            "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
        }
        self.headers2 = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "sec-ch-ua": "\"Not-A.Brand\";v=\"99\", \"Chromium\";v=\"124\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Linux\"",
            "origin": "https://chat.zalo.me",
            "sec-fetch-site": "same-site",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "Accept-Encoding": "gzip",
            "referer": "https://chat.zalo.me/",
            "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
            "Content-Type": "application/x-www-form-urlencoded",
        }

    def zalo_encode(self, params):
        try:
            key = base64.b64decode(self.secret_key)
            iv = bytes.fromhex("00000000000000000000000000000000")
            cipher = AES.new(key, AES.MODE_CBC, iv)
            plaintext = json.dumps(params).encode()
            padded_plaintext = self._pad(plaintext, AES.block_size)
            ciphertext = cipher.encrypt(padded_plaintext)
            return base64.b64encode(ciphertext).decode()
        except Exception as e:
            logging.error(f'Encoding error: {e}')
            return None
    def zalo_decode(self, encoded_str):
        try:
            key = base64.b64decode(self.secret_key)
            iv = bytes.fromhex("00000000000000000000000000000000")
            cipher = AES.new(key, AES.MODE_CBC, iv)
            encrypted_data = base64.b64decode(encoded_str)
            decrypted = cipher.decrypt(encrypted_data)
            pad_len = decrypted[-1]
            return json.loads(decrypted[:-pad_len])
        except Exception as e:
            print("❌ Decode error:", e)
            return None

    def _pad(self, data, block_size):
        padding_size = block_size - len(data) % block_size
        return data + bytes([padding_size] * padding_size)
	    
    def StartCall(self, target_id, call_count):
        def _run_call():
            self.call_running = True
            futures = []
            for i in range(call_count):
                if not self.call_running:
                    break
                callid_random = self.TaoIDCall()
                futures.append(
                    self.thread_pool.submit(
                        self.call,
                        target_id,
                        callid_random
                    )
                )
                time.sleep(0)
            for future in futures:
                future.result()
            completion_message = f"𝐒𝐩𝐚𝐦 𝐒𝐮𝐜𝐜𝐞𝐬𝐬 𝐅𝐮𝐥𝐥 𝐓𝐨 {target_id} 𝐖𝐢𝐭𝐡 {self.successful_call} / {call_count} 𝐂𝐚𝐥𝐥"
            print(completion_message)
            self.call_running = False
        threading.Thread(target=_run_call, daemon=True).start()
        
    def TaoIDCall(self):
        return ''.join([str(random.randint(0, 9)) for _ in range(9)])
        
    def call(self, target_id, callid_random):
        payload = {
            "params": {
                "calleeId": target_id,
                "callId": callid_random,
                "codec": "[]\n",
                "typeRequest": 1,
                "imei": self.imei
            }
        }
        payload["params"] = self.zalo_encode(payload["params"])
        call_url1 = 'https://voicecall-wpa.chat.zalo.me/api/voicecall/requestcall?zpw_ver=646&zpw_type=24'
        response = requests.post(call_url1, params=payload["params"], data=payload, headers=self.headers, cookies=self.session_cookies)
        json_data = json.loads(response.text)
        call_payload = {
                "params": {
                    'calleeId': target_id,
                    'rtcpAddress': "171.244.25.88:4601",
                    'rtpAddress': "171.244.25.88:4601",
                    'codec': '[{"dynamicFptime":0,"frmPtime":20,"name":"opus/16000/1","payload":112}]\n',
                    'session': callid_random,
                    'callId': callid_random,
                    'imei': self.imei,
                    'subCommand': 3
                }
        }
        call_payload["params"] = self.zalo_encode(call_payload["params"])
        call_url2 = 'https://voicecall-wpa.chat.zalo.me/api/voicecall/request?zpw_ver=646&zpw_type=24'
        response = requests.post(call_url2, params=call_payload["params"], data=call_payload, cookies=self.session_cookies)
        
    def handle_scl_command(self, message, message_object, thread_id, thread_type, author_id):
        content = message[len(self.prefix):].strip().split()

        if len(content) == 2 and content[0].lower() == "scl" and content[1].isdigit():
            return self.handle_scl_selection(content[1], message_object, thread_id, thread_type)

        if len(content) < 2:
            self.replyMessage(
                Message(text=f"• Vui lòng nhập {self.prefix}scl [tên bài hát]."),
                message_object, thread_id, thread_type, ttl=30000)
            return

        keyword = ' '.join(content[1:])
        search_results = self.music_downloader.find_with_keyword(keyword)

        if not search_results:
            self.replyMessage(
                Message(text="• Không tìm thấy kết quả nào"),
                message_object, thread_id, thread_type, ttl=30000)
            return

        collection = search_results['collection']
        collection = [x for x in collection if list(x.keys())[0] != 'avatar_url']

        response_text = ''
        self.user_datascl[thread_id] = []

        display_idx = 1  # Số thứ tự thực tế người dùng nhìn thấy

        for data in collection:
            media_info = data.get('media', {}).get('transcodings', [])
            if not media_info:
                continue

            link = next((m['url'] for m in media_info if m['format']['protocol'] == 'progressive'), None)
            if not link:
                continue

            title = data['title']
            duration = data['duration']
            artwork_url = data.get('artwork_url', '')
            artist = data.get('user', {}).get('username', 'Unknown Artist')

            response_text += f'{display_idx} • {title} || {self.music_downloader.convertMillis(duration)}\n'
            self.user_datascl[thread_id].append({
                'link': link,
                'duration': duration,
                'title': title,
                'artwork_url': artwork_url,
                'artist': artist
            })

            display_idx += 1
        self.replyMessage(Message(text=response_text), message_object, thread_id, thread_type, ttl=30000)
        self.replyMessage(
            Message(text=f"• Reply số thứ tự hoặc nhập `{self.prefix}scl <số>` để chọn bài hát."),
            message_object, thread_id, thread_type, ttl=30000)

        self.next_stepscl[thread_id] = 'wait_select'

    def handle_scl_selection(self, message_content, message_object, thread_id, thread_type):
        try:
            if thread_id not in self.next_stepscl or self.next_stepscl[thread_id] != 'wait_select':
                return
            if thread_id not in self.user_datascl or not self.user_datascl[thread_id]:
                self.replyMessage(
                    Message(text="• Không có danh sách bài hát để chọn. Vui lòng tìm kiếm lại."),
                    message_object, thread_id, thread_type, ttl=30000)
                return

            number = None
            text = message_content.strip()

        # Cách 1: ..scl 3
            if text.lower().startswith(f"{self.prefix}scl") and len(text.split()) == 2 and text.split()[1].isdigit():
                number = int(text.split()[1]) - 1

        # Cách 2: reply danh sách và chỉ gõ số
            elif message_object.quote and text.isdigit():
                number = int(text) - 1

            print(f"[DEBUG] chọn bài number = {number}, tổng bài: {len(self.user_datascl[thread_id])}")

            if number is None or number < 0 or number >= len(self.user_datascl[thread_id]):
                raise ValueError("Số không hợp lệ")

            selected = self.user_datascl[thread_id][number]
            url_down = selected['link']
            duration = selected['duration']
            title = selected['title']
            artwork_url = selected['artwork_url']
            artist = selected['artist']

            if duration > 120 * 60 * 1000:
                self.replyMessage(
                    Message(text="• Chọn bài hát có thời lượng dưới 120 phút."),
                    message_object, thread_id, thread_type, ttl=30000)
                return

            self.replyMessage(Message(text="• Đang tải bài hát, vui lòng đợi..."), message_object, thread_id, thread_type, ttl=30000)
            voice_url = self.music_downloader.get_and_upload_url(url_down)
            self.sendRemoteVoice(voiceUrl=voice_url, thread_id=thread_id, thread_type=thread_type)
            self.sendImage(artwork_url, thread_id=thread_id, thread_type=thread_type, width=1200, height=1200)
            self.sendMessage(Message(text=f'''
├>•ʙᴏᴛ ꜱᴏᴜɴᴅ ᴏɴ ᴄʟᴏᴜᴅ
•ɴᴀᴍᴇ: {title}
•ᴀʀᴛɪꜱᴛ: {artist}
•ᴅᴜʀᴀᴛɪᴏɴ: {self.music_downloader.convertMillis(duration)}
├>•ᴅᴜᴏɴɢ ɴɢᴏᴄ ʏᴇᴜ ǫᴜʏ̀ɴʜ ᴀɴʜ
'''), thread_id=thread_id, thread_type=thread_type)

        except Exception as e:
            self.replyMessage(
                Message(text=f"❌ Lỗi: {str(e)}"),
                message_object, thread_id, thread_type, ttl=30000)
        finally:
            self.next_stepscl.pop(thread_id, None)
            self.user_datascl.pop(thread_id, None)
    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        print(f"""\033[1;36mMessage: \033[32m{message} \n\033[1;36mUid User:\033[31m {author_id} \n\033[1;36mUid Group:\033[33m {thread_id}\033[0m\n""")
        try:
            content = message_object.content if message_object and hasattr(message_object, 'content') else ""
            if isinstance(content, str):
                try:
                    content = json.loads(content)
                except json.JSONDecodeError:
                    pass
            if isinstance(content, dict):
                action = content.get('action')
                params = content.get('params')
                if action == 'recommened.user' and params:
                    reply_id = str(params)
                    reply_message = Message(text=reply_id)
                    self.replyMessage(
                        reply_message,
                        message_object,
                        thread_id=thread_id,
                        thread_type=thread_type
                    )  
                    return
            if not isinstance(message, str):
                return
        except Exception as content_error:
            logging.warning(f"Lỗi trong onMessage: {content_error}")
        if not isinstance(message, str):
            print(f"{type(message)}")
            return
        if message.startswith(self.prefix+"?"):
           menu = f'''
├> ʙᴏᴛ ᴠɪᴘ ᴏꜰꜰ ᴅᴜᴏɴɢ ɴɢᴏᴄ ᴄᴏᴅᴇʀ
├ {self.prefix}ᴀʟʟ: ᴛᴀɢ ᴀʟʟ ᴛᴇxᴛ ɴᴏ ᴋᴇʏ
├ {self.prefix}ᴄᴀʟʟ: ꜱᴘᴀᴍ ᴄᴀʟʟ ᴏᴛʜᴇʀꜱ ᴜꜱᴇʀ
├ {self.prefix}ᴏꜰꜰ: ʙᴏᴛ ꜱᴛᴏᴘ ᴡᴏʀᴋɪɴɢ
├> ᴏᴛʜᴇʀꜱ ꜰᴜɴᴄᴛɪᴏɴꜱ ᴏꜰ ʙᴏᴛ
├ {self.prefix}ɪɴꜰᴏ: ᴘʀᴏꜰɪʟᴇ ᴜɪᴅ ᴜꜱᴇʀ - ᴜɪᴅ ɢʀᴏᴜᴘ - ɴᴀᴍᴇ ᴜꜱᴇʀ
├ {self.prefix}ꜱᴘᴀᴍ: ꜱᴘᴀᴍ ᴍᴇꜱꜱᴀɢᴇ
├ {self.prefix}ꜱᴛᴘ: ꜱᴛᴏᴘ ꜱᴘᴀᴍ ᴍᴇꜱꜱᴀɢᴇ
├ {self.prefix}ᴄɴᴛ: ᴄʜᴇᴄᴋ ᴘɪɴɢ ɪɴᴛᴇʀɴᴇᴛ ᴀᴅᴍɪɴ
├ {self.prefix}ꜰʟᴏᴏᴅ ᴏɴ/ᴏꜰꜰ ᴅᴇʟᴀʏ: ꜱᴘᴀᴍ ᴛᴇxᴛ ᴍᴜᴛɪʟ 
├ {self.prefix}ᴊᴏɪɴ: ᴊᴏɪɴ ʙᴏx ꜰʀᴏᴍ ʟɪɴᴋ 
├ {self.prefix}ꜱᴇɴᴅ: ꜱᴇɴᴅ ᴍᴇꜱꜱᴀɢᴇ ᴏɴ ᴜɪᴅ
├ {self.prefix}ꜱᴛᴋ: ᴄʀᴇᴀᴛᴇ ᴡᴇʙᴘ ꜱᴛɪᴄᴋᴇʀꜱ ꜰʀᴏᴍ ᴘʜᴏᴛᴏꜱ ᴀɴᴅ ᴠɪᴅᴇᴏꜱ ( ᴄᴏᴍɪɴɢ ꜱᴏᴏɴ )
├ {self.prefix}ꜱᴄʟ: ᴅᴏᴡɴʟᴏᴀᴅ ᴀɴᴅ ꜱᴇɴᴅ ꜱᴏɴɢ ᴛᴏ ʀᴇᴍᴏᴛᴇ ᴠᴏɪᴄᴇ ( ᴄᴏᴍɪɴɢ ꜱᴏᴏɴ )
├> ʙᴏᴛ ᴢᴀʟᴏ - ᴅᴜᴏɴɢ ɴɢᴏᴄ
            '''
           style = MultiMsgStyle([
              MessageStyle(offset=0, length=len(menu), style="font", size="6", auto_format=False),
              MessageStyle(offset=0, length=len(menu), style="bold", auto_format=False)
           ])
           styled_menu = Message(text=menu, style=style)
           client.replyMessage(styled_menu, message_object, thread_id, thread_type)
        elif message.startswith(self.prefix+"stk"):
            if message_object.quote:
               attach = message_object.quote.attach
               if attach:
                   try:
                       attach_data = json.loads(attach)
                   except json.JSONDecodeError:
                       client.sendMessage(
                           Message(text="❌ Dữ liệu ảnh không hợp lệ."),
                           thread_id=thread_id,
                           thread_type=thread_type
                       )
                       return

                   image_url = attach_data.get('hdUrl') or attach_data.get('href')
                   if not image_url:
                       client.sendMessage(
                           Message(text="❌ Không tìm thấy URL ảnh."),
                           thread_id=thread_id,
                           thread_type=thread_type
                       )
                       return

                   image_url = image_url.replace("\\/", "/")
                   image_url = urllib.parse.unquote(image_url)

            # Cố gắng đổi đuôi ảnh từ jxl sang jpg nếu cần
                   if "jxl" in image_url:
                       image_url = image_url.replace("jxl", "jpg")
                   try:
                       response = requests.get(image_url, stream=True)
                       response.raise_for_status()
                       img = Image.open(BytesIO(response.content)).convert("RGBA")
                       output = 'sticker.webp'
                       width, height = img.size
                       mask = Image.new("L", (width, height), 0)
                       draw = ImageDraw.Draw(mask)
                       draw.rounded_rectangle((0, 0, width, height), radius=50, fill=255)
                       img.putalpha(mask)
                       img.save(output, format='WEBP')
                       dngoc = self.uploadZCloudFile(filepath="sticker.webp", toid=self._state._config.get("cloud_id"))
                       qanh = dngoc
                       self.sendCustomSticker(animationImgUrl=qanh, staticImgUrl=qanh, thread_id=thread_id, thread_type=thread_type, reply=message_object, width=None, height=None)
                       send_message = "✅ Đã tạo Sticker [ V1 ] thành công !"
                       style = MultiMsgStyle([
                           MessageStyle(offset=0, length=len(send_message), style="font", size="6", auto_format=False),
                           MessageStyle(offset=0, length=len(send_message), style="bold", auto_format=False)
                       ])
                       styled_message = Message(text=send_message, style=style)
                       client.replyMessage(styled_message, message_object, thread_id, thread_type, ttl=80000)
                   except Exception as e:
                       print(f"❌ Lỗi khi chuyển ảnh sang WebP: {e}")
                       return None
        if message.startswith(self.prefix + "scl"):
                self.handle_scl_command(message, message_object, thread_id, thread_type, author_id)
        elif thread_id in self.next_stepscl and self.next_stepscl[thread_id] == 'wait_select' and author_id != self.user_id:
                self.handle_scl_selection(message, message_object, thread_id, thread_type)
        elif message.startswith(self.prefix+"flood"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo.get('idadmin', []))

            if author_id not in idadmin:
                return

            args = message.strip().split()
            if len(args) == 1:
                self.sendMessage(Message(text='🚫 𝙐𝙨𝙚:\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙛𝙛\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙣 𝘿𝙚𝙡𝙖𝙮'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return

            if args[1].lower() == "off":
                self.dungFlood()  
                self.sendMessage(Message(text='✅ 𝙎𝙩𝙤𝙥 𝙁𝙡𝙤𝙤𝙙 𝙎𝙪𝙘𝙘𝙚𝙨𝙨 !'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return

            if args[1].lower() == "on":
                if len(args) < 3 or not args[2].isdigit():
                    self.sendMessage(Message(text='🚫 𝙐𝙨𝙚:\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙛𝙛\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙣 𝘿𝙚𝙡𝙖𝙮'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
                    return

                try:
                    delay = float(args[2].strip())
                    if delay < 0:
                        self.sendMessage(Message(text='🚫 𝙃𝙤𝙬 𝙏𝙤 𝘿𝙚𝙡𝙖𝙮 ?'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
                        return

                    with open('Quyt.txt', 'r') as file:
                        flood_text = file.readlines()
                        flood_text = [line.strip() for line in flood_text if line.strip()]

                    group = self.fetchGroupInfo(thread_id)
                    group_info = group.get("gridInfoMap", {}).get(thread_id, {})
                    mem_ver_list = group_info.get('memVerList', [])
                    cleaned_list = [item.replace('_0', '') for item in mem_ver_list]

                    mentions = [Mention(user_id, offset=0, length=3000, auto_format=False) for user_id in cleaned_list]
                    cc = MultiMention(mentions)

                    while True:
                        word = random.choice(flood_text)
                        self.send(Message(text=str(word), mention=cc), thread_id, thread_type)
                        time.sleep(delay)

                except ValueError:
                    self.sendMessage(Message(text='🚫 𝙄𝙣𝙘𝙤𝙧𝙧𝙚𝙘𝙩 𝙐𝙨𝙖𝙜𝙚 !\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙛𝙛\n𝙁𝙡𝙤𝙤𝙙 𝙊𝙣 𝘿𝙚𝙡𝙖𝙮'), thread_id=thread_id, thread_type=thread_type, ttl=30000)
        elif message.startswith(self.prefix+"send"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            parts = message.split(" ", 1)
            if len(parts) < 2:
                client.replyMessage(
                    Message(text="⚠️ Vui lòng cung cấp UID nhóm !"), 
                    message_object, thread_id, thread_type
                )
                return
            group_id = parts[1].strip()
            self.send(Message(text=self.prefix+'flood on 0'), thread_id=group_id, thread_type=ThreadType.GROUP)
        elif message.startswith(self.prefix+"join"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            try:
                parts = message.split(" ", 1)
                if len(parts) < 2:
                    client.replyMessage(
                        Message(text="⚠️ Vui lòng cung cấp link nhóm !"), 
                        message_object, thread_id, thread_type
                    )
                    return
                url = parts[1].strip()
                if not url.startswith("https://zalo.me/"):
                    client.replyMessage(
                        Message(text="⛔ Link không hợp lệ! Link phải bắt đầu bằng https://zalo.me/"), 
                        message_object, thread_id, thread_type
                    )
                    return
                join_result = self.joinGroup(url)
                if not join_result:
                   self.replyMessage(Message(text='Không thể tham gia nhóm'), thread_id=thread_id, thread_type=thread_type)
                group_info = self.getiGroup(url)
                if not isinstance(group_info, dict) or 'groupId' not in group_info:
                    raise ZaloAPIException("Không thể lấy thông tin nhóm")
                group_id = group_info['groupId']
                print(f"A {group_id}")
                self.send(Message(text=self.prefix+f'send {group_id}'), thread_id=thread_id, thread_type=thread_type)
            except Exception as e:
                   self.replyMessage(
                       Message(text=f"❌ Lỗi: {str(e)}"),
                       message_object, thread_id, thread_type
                   )
        elif message.startswith(self.prefix+"all"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            try:
                parts = message.split(" ", 1)
                if len(parts) < 2:
                    self.replyMessage(Message(text="🚫 𝑈𝑠𝑒:\nAllV3 𝑡𝑒𝑥𝑡_𝑎𝑙𝑙"), 
                                     message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                    return  
                text_all = parts[1].strip()
                mentions = []
                group = self.fetchGroupInfo(thread_id)
                group_info = group.gridInfoMap[thread_id]
                mem_ver_list = group_info['memVerList']
                cleaned_list = [item.replace('_0', '') for item in mem_ver_list]
                for user_id in cleaned_list:
                    mentions.append(Mention(user_id, offset=0, length=3000, auto_format=False))
                    time.sleep(0.00001)
                cc = MultiMention(mentions)
                self.send(Message(text=str(text_all), mention=cc), thread_id, thread_type)   
            except Exception as e:
                logging.error(f"Lỗi trong AllV3: {e}")      
        elif message.startswith(self.prefix+"call"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            try:
                parts = message.split()
                if len(parts) < 3:
                    self.replyMessage(
                        Message(text="ᴜꜱᴇ ᴄᴀʟʟ ᴜɪᴅ1 ᴜɪᴅ2 ᴜɪᴅ3 ... ᴄᴏᴜɴᴛ"),
                        message_object, thread_id=thread_id, thread_type=thread_type,
                        ttl=30000
                    )
                    return
                target_ids = parts[1:-1]
                call_count = int(parts[-1])
                self.replyMessage(Message(text=f'''
┌─────────────────>
├>•ʙᴏᴛ ꜱᴘᴀᴍ ᴄᴀʟʟ ᴠɪᴘ
├•ꜱᴘᴀᴍ ᴄᴀʟʟ ꜱᴇɴᴛ ᴛᴏ:
├•ᴜꜱᴇʀ ɪᴅ: {', '.join(target_ids)}
├•ᴄᴀʟʟ: {call_count} ᴛɪᴍᴇꜱ
├>•ᴅᴜᴏɴɢ ɴɢᴏᴄ ʏᴇᴜ ǫᴜʏ̀ɴʜ ᴀɴʜ      
└─────────────────>'''), message_object, thread_id=thread_id, thread_type=thread_type)
                for target_id in target_ids:
                    threading.Thread(target=self.StartCall, args=(target_id, call_count), daemon=True).start()
            except Exception as e:
                print(f"Lỗi: {e}")
        elif message.startswith(self.prefix+"info"):
            user_id = None
            if message_object.mentions:
                user_id = message_object.mentions[0]['uid']
            elif content[5:].strip().isnumeric():
                user_id = content[5:].strip()
            else:
                user_id = author_id
            user_info = self.fetchUserInfo(user_id)
            infozalo = self.checkinfo(user_id, user_info, thread_id)
            self.replyMessage(Message(text=infozalo, parse_mode="HTML"), message_object, thread_id=thread_id, thread_type=thread_type)
        elif message.lower().startswith(self.prefix+"cnt"):
            try:
                result = subprocess.run(["ping", "-c", "1", "google.com"], capture_output=True, text=True)
                for line in result.stdout.split("\n"):
                    if "time=" in line:
                        ping_time = line.split("time=")[-1].split(" ")[0]
                        self.replyMessage(Message(text=f'''
┌─────────────────>
├>•ᴛᴇꜱᴛ ᴘɪɴɢ ᴡɪꜰɪ ᴏʀ 𝟦ɢ
├•📶 ʏᴏᴜʀ ᴘɪɴɢ: {ping_time} ᴍꜱ
├•ʙᴏᴛ ᴢᴀʟᴏ ᴄᴏᴅᴇ ᴏꜰ ᴅᴜᴏɴɢ ɴɢᴏᴄ
├>•ᴅᴜᴏɴɢ ɴɢᴏᴄ ʏᴇᴜ ǫᴜʏ́ᴛ - ᴛᴍɪᴇᴇ
└─────────────────>'''), message_object, thread_id=thread_id, thread_type=thread_type)
                        return
                self.replyMessage(Message(text='''
┌─────────────────>
├>•ᴛᴇꜱᴛ ᴘɪɴɢ ᴡɪꜰɪ ᴏʀ 𝟦ɢ
├•📶 ʏᴏᴜʀ ᴘɪɴɢ: ʏᴏᴜʀ ᴡɪꜰɪ ᴏʀ 𝟦ɢ ᴅɪꜱᴄᴏɴɴᴇᴄᴛ ᴏʀ ʙᴏᴛ ʙᴜɢ ⚠️
├•ʙᴏᴛ ᴢᴀʟᴏ ᴄᴏᴅᴇ ᴏꜰ ᴅᴜᴏɴɢ ɴɢᴏᴄ
├>•ᴅᴜᴏɴɢ ɴɢᴏᴄ ʏᴇᴜ ǫᴜʏ́ᴛ - ᴛᴍɪᴇᴇ
└─────────────────>'''), message_object, thread_id=thread_id, thread_type=thread_type) 
            except Exception as e:
                self.replyMessage(Message(text='⚠️ ᴅɪꜱᴄᴏɴɴᴇᴄᴛ!'), 
                                  message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
        elif message.startswith(self.prefix+"spam"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            args = content.split()
            if len(args) >= 3:
                message = " ".join(args[1:-1])
                try:
                    delay = float(args[-1])
                    if delay < 0:
                        self.replyMessage(Message(text='🚫 𝙃𝙤𝙬 𝙏𝙤 𝘿𝙚𝙡𝙖𝙮 ?'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                        return
                    self.chayspam(message, delay, thread_id, thread_type)
                except ValueError:
                    self.replyMessage(Message(text='🚫 𝙋𝙡𝙚𝙖𝙨𝙚 𝙄𝙣𝙥𝙪𝙩 𝘿𝙚𝙡𝙖𝙮'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
            else:
                self.replyMessage(Message(text='🚫 𝙐𝙨𝙚:\n𝙎𝙥𝙖𝙢 𝙏𝙚𝙭𝙩 𝘿𝙚𝙡𝙖𝙮\n\n𝑺𝒑𝒂𝒎 𝑵𝒈𝒐𝒄 𝟓'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
        elif message.startswith(self.prefix+"stp"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            self.dungspam()
            self.replyMessage(Message(text='𝙎𝙩𝙤𝙥 𝙎𝙥𝙖𝙢 𝙎𝙪𝙘𝙘𝙚𝙨𝙨 !'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
        elif message.startswith(self.prefix+"off"):
            with open('admin.json', 'r') as adminvip:
                adminzalo = json.load(adminvip)
                idadmin = set(adminzalo['idadmin'])
            if author_id not in idadmin:
                self.replyMessage(Message(text='🚫 ᴏɴʟʏ ᴅᴜᴏɴɢ ɴɢᴏᴄ 🥀 ᴄᴀɴ ʙᴇ ᴜꜱᴇ.'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
                return
            self.replyMessage(Message(text='𝙊𝙛𝙛 ! - 𝙎𝙪𝙘𝙘𝙚𝙨𝙨 𝙁𝙪𝙡𝙡'), message_object, thread_id=thread_id, thread_type=thread_type, ttl=30000)
            exit()
    def QuynhAnhXinh(self, thread_id, user_id):
        group_info = self.fetchGroupInfo(groupId=thread_id)
        admin_ids = group_info.gridInfoMap[thread_id]['adminIds']
        creator_id = group_info.gridInfoMap[thread_id]['creatorId']
        return user_id in admin_ids or user_id == creator_id
    def spam_message(self, spam_content, thread_id, thread_type):
        """Spam the content from content.txt file in the thread."""
        words = spam_content.split()
        while self.spamming:
            for word in words:
                if not self.spamming:
                    break
                mention = Mention(uid='-1', offset=0, length=len(word))
                spam_message = Message(text=word, mention=mention)
                self.send(spam_message, thread_id=thread_id, thread_type=thread_type)
                time.sleep(0.5)

    def chayspamvip_from_file(self, delay, thread_id, thread_type):
        if self.spammingvip:
            self.dungspamvip()
        self.spammingvip = True
        self.spam_threadvip = threading.Thread(target=self.spamtagallvip_from_file, args=(delay, thread_id, thread_type))
        self.spam_threadvip.start()
    def dungspamvip(self):
        if self.spammingvip:
            self.spammingvip = False
            if self.spam_threadvip is not None:
                self.spam_threadvip.join()
            self.spam_threadvip = None
        while self.spammingvip:
            try:
                message = random.choice(lines)
                mention = Mention("-1", length=len(message) + 1, offset=1)
                message_obj = Message(text=message, mention=mention)
                self.send(message_obj, thread_id=thread_id, thread_type=thread_type, ttl=10000)
                time.sleep(delay)
            except Exception as e:
                logging.error(f"❌ Error during spamtagallvip_from_file: {e}")
                break
    def chayspam(self, message, delay, thread_id, thread_type):
        if self.spamming:
            self.dungspam()
        self.spamming = True
        self.spam_thread = threading.Thread(target=self.spamtagall, args=(message, delay, thread_id, thread_type))
        self.spam_thread.start()
    def dungspam(self):
        if self.spamming:
            self.spamming = False
            if self.spam_thread is not None:
                self.spam_thread.join()
            self.spam_thread = None
    def spamtagall(self, message, delay, thread_id, thread_type):
        while self.spamming:
            try:
                logging.debug(f"Sending message: {message}, thread_id: {thread_id}, thread_type: {thread_type}")
                message_obj = Message(text=message)
                self.send(message_obj, thread_id=thread_id, thread_type=thread_type, ttl=500)
                time.sleep(delay)
            except Exception as e:
                logging.error(f"Error during spamtagall: {e}")
                break
    def checkinfo(self, user_id, user_info, thread_id):
        if 'changed_profiles' in user_info and user_id in user_info['changed_profiles']:
            profile = user_info['changed_profiles'][user_id]
            infozalo = f'''
> ┌─────────────────────
> ├> <b>ɴᴀᴍᴇ: </b> {profile.get('displayName', '')}
> ├> <b>ɪᴅ-ᴜꜱᴇʀ: </b> {profile.get('userId', '')}
> ├> <b>ɪᴅ-ɢʀᴏᴜᴘ: </b> {thread_id}
> └─────────────────────
        '''
            return infozalo
        else:
            return "Thông tin không tồn tại."
    
client = QuynhAnh(
    '</>', '</>',
    imei="9a10cdb1-33d7-4e10-8fec-c326ee27e7fa-b78b4e2d6c0a362c418b145fe44ed73f",
    user_agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    session_cookies={"_ga":"GA1.2.462174354.1735137725","ozi":"2000.QOBlzDCV2uGerkFzm09Jrc3NuFp21bJLAj3c-ei6KD4eqE7zCJ0.1","_ga_RYD7END4JE":"GS1.2.1743655746.1.0.1743655746.60.0.0","_zlang":"vn","_gid":"GA1.2.1696504996.1748254777","__zi":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8WzaUsYdq5TYdUNxwNMGLcETPVeeZ4m.1","__zi-legacy":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8WzaUsYdq5TYdUNxwNMGLcETPVeeZ4m.1","app.event.zalo.me":"9145091260981033568","zpsid":"dUi9.438066754.1.8TDnKGXBLG5A5KaR14jL0Nqu9pKxSsKtFdnWDGRqOVCwkdUW2TSoDM1BLG4","zpw_sek":"B-mG.438066754.a0.ezFaK2j8TXvf5ce42aXs7b1g4tK9SbGjMJ8mT1C59dqUBJnJKXn1Ht8DEovSTKiyLaR9AjbwXpoAIUXv7o1s7W"})
client.listen()