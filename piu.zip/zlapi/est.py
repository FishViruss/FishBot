# ... giữ nguyên tất cả như cũ ở trên ...

        self._fileUploadFutures = {}  # thêm dòng này vào trong __init__()

# ... giữ nguyên các hàm khác như cũ ...

    def uploadAsyncFile(self, filepath, toid):
        file_size = os.path.getsize(filepath)
        client_id = _util.now()
        self._uploadingClientId = client_id  # lưu lại client_id đang chờ

        future = Future()
        self._fileUploadFutures[client_id] = future

        encoded_payload = self._encode({
            "totalChunk": 1,
            "fileName": os.path.basename(filepath),
            "clientId": client_id,
            "totalSize": file_size,
            "imei": self.imei,
            "chunkId": 1,
            "toid": toid
        })

        url = "https://tt-files-wpa.chat.zalo.me/api/message/asyncfile/upload"
        params = {"zpw_ver": 657, "zpw_type": 30}
        with open(filepath, "rb") as f:
            files = {
                'file': (os.path.basename(filepath), f, 'application/octet-stream')
            }
            response = self._post(url, params=params, data={"params": encoded_payload}, files=files)

        data = response.json()
        print(data)
        if data.get("error_code") != 0:
            raise ZaloAPIException(f"❌ Upload thất bại: {data}")

        try:
            file_url = future.result(timeout=10)
            print(f"✅ Nhận được fileUrl: {file_url}")
            return file_url
        except Exception as e:
            raise TimeoutError("❌ Timeout khi chờ fileUrl từ fileEvent")

    def fileEvent(self, data, types):
        print("[ZALO FILE EVENT]", data)
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except:
                return

        file_url = data.get("fileUrl")
        client_id = data.get("clientId") or data.get("client_id")

        if file_url and client_id in self._fileUploadFutures:
            future = self._fileUploadFutures.pop(client_id)
            future.set_result(file_url)
            print(f"✅ Đã gán fileUrl cho client_id {client_id}")
        else:
            print("❌ Không tìm thấy fileUrl hoặc client_id")

    def onWebSocketMessage(self, parsedData):
        n = parsedData.get("n")
        cmd = parsedData.get("cmd")
        s = parsedData.get("s")

        if n == 1 and cmd == 601 and s == 0:
            controls = parsedData["data"].get("controls", [])
            for control in controls:
                if control["content"].get("act_type") == "file":
                    pool.submit(self.fileEvent, data=control["content"].get("data"), types=control["content"].get("act"))
                    